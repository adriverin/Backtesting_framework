"""Utility script to visualise cumulative returns for an asset and a strategy.

The script takes similar CLI parameters as the other general testers and will:

1. Load OHLCV data for the requested asset/time-frame.
2. Optimise the specified strategy on the in-sample slice (or full slice if no
   specific split is desired).
3. Generate the strategy's signals on that slice.
4. Compute log-returns of the asset and the strategy.
5. Plot both cumulative return curves in the same figure.
6. Print summary metrics: Profit Factor, Sharpe ratio and total % return.

Example
-------

python plot_cumulative_returns.py \
    --start 2018-01-01 --end 2020-01-01 \
    --strategy ml_rsi_ema_volume --asset BTCUSD --tf 1h --plot
"""
from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Type

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from strategies import aVAILABLE_STRATEGIES, BaseStrategy  # type: ignore

# ---------------------------------------------------------------------- #
# Helper utilities                                                       #
# ---------------------------------------------------------------------- #

def _profit_factor(returns: pd.Series) -> float:
    positive_sum = returns[returns > 0].sum()
    negative_sum = returns[returns < 0].abs().sum()
    if negative_sum == 0:
        return float("inf") if positive_sum > 0 else 0.0
    return positive_sum / negative_sum


def _annualisation_factor(timeframe: str) -> float:
    """Return the sqrt annualisation factor for the given timeframe string."""
    tf = timeframe.lower().strip()
    minutes_per_unit = 1
    if tf.endswith("m"):
        minutes_per_unit = int(tf[:-1])
    elif tf.endswith("h"):
        minutes_per_unit = int(tf[:-1]) * 60
    elif tf.endswith("d"):
        minutes_per_unit = int(tf[:-1]) * 60 * 24
    else:
        raise ValueError(f"Unsupported timeframe format: {timeframe}")

    periods_per_year = (365 * 24 * 60) / minutes_per_unit
    return math.sqrt(periods_per_year)


# ---------------------------------------------------------------------- #
# Core plotting logic                                                    #
# ---------------------------------------------------------------------- #


def plot_cumulative_returns(
    start_date: str,
    end_date: str,
    strategy_name: str,
    asset: str,
    timeframe: str,
    price_column: str = "close",
    strategy_kwargs: dict | None = None,
    show_plot: bool = True,
):
    strategy_kwargs = strategy_kwargs or {}

    if strategy_name not in aVAILABLE_STRATEGIES:
        raise ValueError(
            f"Unknown strategy '{strategy_name}'. Available: {list(aVAILABLE_STRATEGIES)}"
        )

    # ------------------------------------------------------------------ #
    # Load data                                                          #
    # ------------------------------------------------------------------ #
    filepath = Path(f"data/ohlcv_{asset}_{timeframe}.parquet")
    if not filepath.exists():
        raise FileNotFoundError(filepath)
    df = pd.read_parquet(filepath)
    df = df[(df.index >= start_date) & (df.index < end_date)].copy()

    if len(df) == 0:
        raise ValueError("No data in the selected date range.")

    # ------------------------------------------------------------------ #
    # Run strategy                                                       #
    # ------------------------------------------------------------------ #
    strategy_cls: Type[BaseStrategy] = aVAILABLE_STRATEGIES[strategy_name]
    strategy = strategy_cls(price_column=price_column, **strategy_kwargs)
    strategy.optimize(df)  # optimise on same slice for simplicity
    signals = strategy.generate_signals(df)

    # ------------------------------------------------------------------ #
    # Compute returns                                                    #
    # ------------------------------------------------------------------ #
    df["r"] = np.log(df[price_column]).diff().shift(-1)
    df["simple_r"] = df[price_column].pct_change().shift(-1)
    df["signal"] = signals
    df["strategy_r"] = df["r"] * df["signal"]

    # Drop NaNs created by diff/shift and any initial NaNs from indicators
    df = df.dropna(subset=["r", "strategy_r"])

    # asset_cum = (1 + df["simple_r"]).cumprod() - 1
    # strat_cum = (1 + df["strategy_r"]).cumprod() - 1
    # asset_cum = df["r"].cumsum().apply(np.exp) - 1.0
    # strat_cum = df["strategy_r"].cumsum().apply(np.exp) - 1.0    
    asset_cum = df["r"].cumsum()
    strat_cum = df["strategy_r"].cumsum()    

    # ------------------------------------------------------------------ #
    # Metrics                                                             #
    # ------------------------------------------------------------------ #
    pf = _profit_factor(df["strategy_r"])
    ann_factor = _annualisation_factor(timeframe)
    sharpe = df["strategy_r"].mean() / df["strategy_r"].std() * ann_factor
    pct_return = strat_cum.iloc[-1] * 100

    print("=" * 80)
    print(f"Results for strategy '{strategy_name}' on {asset} {timeframe}")
    print(f"Period: {start_date} -> {end_date} | Observations: {len(df)}")
    print("-" * 80)
    print(f"Profit Factor : {pf:.4f}")
    print(f"Sharpe Ratio  : {sharpe:.4f}")
    print(f"% Log Return  : {pct_return:.2f}%")
    print("=" * 80)

    # ------------------------------------------------------------------ #
    # Plot                                                               #
    # ------------------------------------------------------------------ #
    if show_plot:
        plt.style.use("dark_background")
        plt.figure(figsize=(12, 6))
        plt.plot(asset_cum.index, asset_cum.values, label=f"{asset} {timeframe}")
        plt.plot(strat_cum.index, strat_cum.values, label=f"Strategy ({strategy_name})")
        plt.xlabel("Date")
        plt.ylabel("Cumulative Log Return")
        # plt.yscale("log")
        plt.title("Cumulative Log Returns")
        plt.legend()
        plt.grid(alpha=0.3)
        plt.tight_layout()
        plt.show()


# ---------------------------------------------------------------------- #
# CLI                                                                    #
# ---------------------------------------------------------------------- #


def main():
    parser = argparse.ArgumentParser(description="Plot cumulative returns of asset and strategy.")
    parser.add_argument("--start", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--end", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--strategy", required=True, help="Strategy identifier")
    parser.add_argument("--asset", required=True, help="Asset symbol e.g. BTCUSD")
    parser.add_argument("--tf", required=True, help="Timeframe e.g. 1h")
    parser.add_argument("--no_plot", action="store_true", help="Skip plotting (only print metrics)")
    args = parser.parse_args()

    plot_cumulative_returns(
        start_date=args.start,
        end_date=args.end,
        strategy_name=args.strategy,
        asset=args.asset,
        timeframe=args.tf,
        show_plot=not args.no_plot,
    )


if __name__ == "__main__":
    # main()

    plot_cumulative_returns(
        start_date="2019-01-01",
        end_date="2024-01-01",
        # strategy_name="ma",
        strategy_name="ml_rsi_ema_volume",
        asset="BTCUSD",
        timeframe="1h",
        show_plot=True,
    )