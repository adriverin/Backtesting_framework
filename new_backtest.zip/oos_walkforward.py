"""Generic walk-forward out-of-sample Monte-Carlo permutation tester.

Refactors *walkforward_test.py* to support any strategy that implements the
*BaseStrategy* interface.
"""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Type

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from strategies import aVAILABLE_STRATEGIES, BaseStrategy  # type: ignore

# ---------------------------------------------------------------------- #
# Utility                                                                 #
# ---------------------------------------------------------------------- #

def _profit_factor(returns: pd.Series) -> float:
    positive_sum = returns[returns > 0].sum()
    negative_sum = returns[returns < 0].abs().sum()
    if negative_sum == 0:
        return float("inf") if positive_sum > 0 else 0.0
    return positive_sum / negative_sum

def _annualisation_factor(timeframe: str) -> float:
    """Return the sqrt annualisation factor for the given timeframe string."""
    tf = timeframe.lower().strip()
    units_per_year = 1
    if tf.endswith("m"):
        units_per_year = int(tf[:-1]) / (365 * 24 * 60)
    elif tf.endswith("h"):
        units_per_year = int(tf[:-1]) / (365 * 24)     
    elif tf.endswith("d"):
        units_per_year = int(tf[:-1]) / (365)        
    else:
        raise ValueError(f"Unsupported timeframe format: {timeframe}")

    return units_per_year

# ---------------------------------------------------------------------- #
# Main tester class                                                       #
# ---------------------------------------------------------------------- #

class WalkForward:
    def __init__(
        self,
        start_date: str,
        end_date: str,
        strategy_name: str,
        asset: str,
        timeframe: str,
        train_lookback: int,
        train_step: int,
        price_column: str = "close",
        generate_plot: bool = False,
        strategy_kwargs: dict | None = None,
    ) -> None:
        self.start_date = start_date
        self.end_date = end_date
        self.strategy_name = strategy_name
        self.asset = asset
        self.timeframe = timeframe
        self.train_lookback = train_lookback
        self.train_step = train_step
        self.price_column = price_column
        self.generate_plot = generate_plot
        self.strategy_kwargs = strategy_kwargs or {}

        if strategy_name not in aVAILABLE_STRATEGIES:
            raise ValueError(
                f"Unknown strategy '{strategy_name}'. Available: {list(aVAILABLE_STRATEGIES)}"
            )
        self.strategy_cls: Type[BaseStrategy] = aVAILABLE_STRATEGIES[strategy_name]




    # ------------------------------------------------------------------ #
    # Data helpers                                                       #
    # ------------------------------------------------------------------ #

    def _get_full_filepath(self) -> Path:
        return Path(f"data/ohlcv_{self.asset}_{self.timeframe}.parquet")

    def _load_raw(self) -> pd.DataFrame:
        return pd.read_parquet(self._get_full_filepath())

    def get_df(self) -> pd.DataFrame:
        # df = self._load_raw()
        # return df[(df.index >= self.start_date) & (df.index < self.end_date)]
        full_df = self._load_raw()
        analysis_start = full_df.index.get_loc(pd.to_datetime(self.start_date, utc=True))
        analysis_end = full_df.index.get_loc(pd.to_datetime(self.end_date, utc=True))
        slice_start = max(0, analysis_start - self.train_lookback)
        return full_df.iloc[slice_start:analysis_end]



    # ------------------------------------------------------------------ #
    # Walk-forward signal generation                                     #
    # ------------------------------------------------------------------ #

    def _walkforward_signals(self, ohlc: pd.DataFrame) -> np.ndarray:
        n = len(ohlc)
        wf_signals = np.full(n, np.nan)
        price_col = self.price_column

        for i in range(self.train_lookback, n, self.train_step):
            train_start = i - self.train_lookback
            train_end = i
            train_df = ohlc.iloc[train_start:train_end]

            # Print the iteration date
            iteration_date = ohlc.index[train_end].strftime("%Y-%m-%d")
            # iteration_date_end = ohlc.index[train_end + self.train_step].strftime("%Y-%m-%d")
            print(f"Processing iteration for date starting on {iteration_date}")

            # Fresh strategy instance for each iteration to avoid leakage
            strategy: BaseStrategy = self.strategy_cls(price_column=price_col, **self.strategy_kwargs)
            _ = strategy.optimize(train_df)

            oos_end = min(i + self.train_step, n)
            long_lookback_ctx = self.train_lookback  # conservative
            signal_calc_start = max(0, train_end - long_lookback_ctx)
            calc_df = ohlc.iloc[signal_calc_start:oos_end]
            oos_signals_full = strategy.generate_signals(calc_df)

            # Extract only new OOS section signals
            oos_section_len = len(ohlc.iloc[train_end:oos_end])
            oos_signals_final = oos_signals_full.iloc[-oos_section_len:].values
            wf_signals[train_end:oos_end] = oos_signals_final

        return wf_signals

    # ------------------------------------------------------------------ #
    # Plot OOS walk-forward                                            #
    # ------------------------------------------------------------------ #

    def run(self):
        real_df = self.get_df()
        ann_factor = _annualisation_factor(self.timeframe)
        print("")
        print("="*100)
        print(
            f"Calculating walk-forward signals for real data from {self.start_date} to {self.end_date}"
        )
        print(f"Train lookback: {self.train_lookback} periods ({self.train_lookback * ann_factor} years)")
        print(f"Train step: {self.train_step} periods ({self.train_step / 24} days)")
        print("="*100)
        print("")
        
        real_signals = self._walkforward_signals(real_df)
        real_df["r"] = np.log(real_df[self.price_column]).diff().shift(-1)
        real_df["signal"] = real_signals
        real_df["strategy_r"] = real_df["r"] * real_df["signal"]

        real_df = real_df[(real_df.index >= self.start_date) & (real_df.index < self.end_date)]

        real_pf = _profit_factor(real_df["strategy_r"].dropna())
        print(f"OOS real Profit Factor: {real_pf:.4f}")

        print("=" * 100)
        print(f"Real PF: {real_pf:.4f}")
        print("=" * 100)

        if self.generate_plot:
            plt.style.use("dark_background")
            plt.figure(figsize=(10, 6))
            plt.plot(real_df["r"].cumsum(), label="Market Log Returns")
            plt.plot(real_df["strategy_r"].cumsum(), label="Strategy Log Returns")
            plt.xlabel("Date")
            plt.ylabel("Cumulative Log Return")
            plt.title(f"Walk-Forward OOS (PF={real_pf:.4f})")
            plt.legend()
            plt.grid(True, alpha=0.3)
            plt.show()


# ---------------------------------------------------------------------- #
# CLI                                                                    #
# ---------------------------------------------------------------------- #


def main():
    parser = argparse.ArgumentParser(description="Generic walk-forward MC tester.")
    parser.add_argument("--start", required=True, help="Start date in YYYY-MM-DD")
    parser.add_argument("--end", required=True, help="End date in YYYY-MM-DD")
    parser.add_argument("--strategy", required=True, help="Strategy identifier")
    parser.add_argument("--asset", required=True, help="Asset symbol, e.g. BTCUSD")
    parser.add_argument("--tf", required=True, help="Timeframe, e.g. 1h")
    parser.add_argument("--lookback", type=int, default=24 * 365 * 4, help="Training lookback periods")
    parser.add_argument("--step", type=int, default=24 * 30, help="Training step size (periods)")
    parser.add_argument("--n_perm", type=int, default=10, help="Number of Monte Carlo permutations")
    parser.add_argument("--plot", action="store_true", help="Generate histogram plot")
    args = parser.parse_args()

    tester = WalkForwardMCTester(
        start_date=args.start,
        end_date=args.end,
        strategy_name=args.strategy,
        asset=args.asset,
        timeframe=args.tf,
        train_lookback=args.lookback,
        train_step=args.step,
        n_perm=args.n_perm,
        generate_plot=args.plot,
    )
    tester.run()


if __name__ == "__main__":
    # main()

    tester = WalkForward(
        start_date="2023-01-01",
        end_date="2024-01-01",
        strategy_name="ma",
        asset="BTCUSD",
        timeframe="1h",
        train_lookback=24*365*4,
        train_step=24*30,
        generate_plot=True,
    )
    tester.run()

