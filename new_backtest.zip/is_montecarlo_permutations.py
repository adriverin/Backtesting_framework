"""Generic in-sample Monte-Carlo permutation test that supports arbitrary strategies.

This is a refactor of *is_testing.py* allowing any strategy that conforms to
*BaseStrategy* to be plugged in.

Usage example from the CLI::

    python is_testing_general.py --start 2018-01-01 --end 2020-01-01 \
        --strategy ma --asset BTCUSD --tf 1h --n_perm 100 --plot

Available strategy identifiers are defined inside *strategies/__init__.py*.
"""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Type

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from tqdm import tqdm

from permutations import get_permutation

from strategies import aVAILABLE_STRATEGIES, BaseStrategy  # type: ignore

# ---------------------------------------------------------------------- #
# Helper functions                                                       #
# ---------------------------------------------------------------------- #


def _profit_factor(returns: pd.Series) -> float:
    positive_sum = returns[returns > 0].sum()
    negative_sum = returns[returns < 0].abs().sum()
    if negative_sum == 0:
        return float("inf") if positive_sum > 0 else 0.0
    return positive_sum / negative_sum

def _annualisation_factor(timeframe: str) -> float:
    """Return the sqrt annualisation factor for the given timeframe string."""
    tf = timeframe.lower().strip()
    minutes_per_unit = 1
    if tf.endswith("m"):
        minutes_per_unit = int(tf[:-1])
    elif tf.endswith("h"):
        minutes_per_unit = int(tf[:-1]) * 60
    elif tf.endswith("d"):
        minutes_per_unit = int(tf[:-1]) * 60 * 24
    else:
        raise ValueError(f"Unsupported timeframe format: {timeframe}")

    periods_per_year = (365 * 24 * 60) / minutes_per_unit
    return math.sqrt(periods_per_year)

# ---------------------------------------------------------------------- #
# Config / Runner class                                                  #
# ---------------------------------------------------------------------- #


class InSampleMCTester:
    """Run in-sample Monte-Carlo permutation test for any given strategy."""

    def __init__(
        self,
        start_date: str,
        end_date: str,
        strategy_name: str,
        asset: str,
        timeframe: str,
        n_perm: int = 100,
        price_column: str = "close",
        generate_plot: bool = False,
        perm_start_index: int = 0,
        strategy_kwargs: dict | None = None,
    ) -> None:
        self.start_date = start_date
        self.end_date = end_date
        self.strategy_name = strategy_name
        self.asset = asset
        self.timeframe = timeframe
        self.n_perm = n_perm
        self.price_column = price_column
        self.generate_plot = generate_plot
        self.perm_start_index = perm_start_index
        self.strategy_kwargs = strategy_kwargs or {}

        if strategy_name not in aVAILABLE_STRATEGIES:
            raise ValueError(
                f"Unknown strategy '{strategy_name}'. Available: {list(aVAILABLE_STRATEGIES)}"
            )

        strategy_cls: Type[BaseStrategy] = aVAILABLE_STRATEGIES[strategy_name]
        self.strategy: BaseStrategy = strategy_cls(price_column=price_column, **self.strategy_kwargs)

    # ------------------------------------------------------------------ #
    # Data helpers                                                       #
    # ------------------------------------------------------------------ #

    def _get_full_filepath(self) -> Path:
        return Path(f"data/ohlcv_{self.asset}_{self.timeframe}.parquet")

    def _load_raw(self) -> pd.DataFrame:
        return pd.read_parquet(self._get_full_filepath())

    def get_df(self) -> pd.DataFrame:
        df = self._load_raw()
        return df[(df.index >= self.start_date) & (df.index < self.end_date)]

    def _get_perm_df(self) -> pd.DataFrame:
        full_df = self._load_raw()
        perm_df = get_permutation(full_df, start_index=self.perm_start_index)
        perm_df = perm_df[(perm_df.index >= self.start_date) & (perm_df.index < self.end_date)]
        return perm_df

    # ------------------------------------------------------------------ #
    # Main logic                                                         #
    # ------------------------------------------------------------------ #

    def run(self):
        train_df = self.get_df()
        print("=" * 100)
        print(f"Optimising strategy '{self.strategy_name}' on in-sample data")
        print(f"from {self.start_date} to {self.end_date}")
        print("=" * 100, "\n")

        _, best_real_pf = self.strategy.optimize(train_df)
        print(f"In-sample PF: {best_real_pf:.4f}")

        iperms_better = 1  # include real sample
        permuted_pfs: list[float] = []
        print("Running Monte-Carlo permutations")
        for perm_i in tqdm(range(1, self.n_perm)):
            perm_df = self._get_perm_df()
            # Fresh strategy instance per permutation to avoid data leakage
            strategy = aVAILABLE_STRATEGIES[self.strategy_name](price_column=self.price_column, **self.strategy_kwargs)
            _ = strategy.optimize(perm_df)
            perm_signals = strategy.generate_signals(perm_df)
            perm_df["r"] = np.log(perm_df[self.price_column]).diff().shift(-1)
            strat_returns = perm_df["r"] * perm_signals
            perm_pf = _profit_factor(strat_returns.dropna())

            if perm_pf >= best_real_pf:
                iperms_better += 1

            permuted_pfs.append(perm_pf)

        p_val = iperms_better / self.n_perm
        print(f"In-sample MC p-value: {p_val:.4f}")
        print(f"Number of permutations better than real PF: {iperms_better}/{self.n_perm}")

        if self.generate_plot:
            print("Generating histogram of permutation PFs …")
            plt.style.use("dark_background")
            pd.Series(permuted_pfs).hist(color="blue", label="Permutations")
            plt.axvline(best_real_pf, color="red", label="Real")
            plt.xlabel("Profit Factor")
            plt.ylabel("Frequency")
            plt.title(f"In-sample MC Permutations (p-value: {p_val:.3f})")
            plt.legend()
            plt.show()


# ---------------------------------------------------------------------- #
# CLI                                                                    #
# ---------------------------------------------------------------------- #


def main():
    parser = argparse.ArgumentParser(description="Generic in-sample MC tester.")
    parser.add_argument("--start", dest="start", required=True, help="Start date (YYYY-MM-DD)")
    parser.add_argument("--end", dest="end", required=True, help="End date (YYYY-MM-DD)")
    parser.add_argument("--strategy", dest="strategy", required=True, help="Strategy identifier")
    parser.add_argument("--asset", dest="asset", required=True, help="Asset symbol, e.g. BTCUSD")
    parser.add_argument("--tf", dest="tf", required=True, help="Timeframe, e.g. 1h")
    parser.add_argument("--n_perm", dest="n_perm", type=int, default=100, help="Number of permutations")
    parser.add_argument("--plot", action="store_true", help="Generate histogram plot")
    args = parser.parse_args()

    tester = InSampleMCTester(
        start_date=args.start,
        end_date=args.end,
        strategy_name=args.strategy,
        asset=args.asset,
        timeframe=args.tf,
        n_perm=args.n_perm,
        generate_plot=args.plot,
    )
    tester.run()


if __name__ == "__main__":
    # main()
    tester = InSampleMCTester(
        start_date="2019-01-01",
        end_date="2024-01-01",
        strategy_name="ma",
        asset="ETHUSD",
        timeframe="1h",
        n_perm=100,
        generate_plot=True,
    )
    tester.run()
